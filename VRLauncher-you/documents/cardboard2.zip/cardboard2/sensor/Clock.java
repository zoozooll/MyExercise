package com.example.sphere.cardboard2.sensor;

/**
 * Created by 111 on 2016/6/22.
 */
public interface Clock {
    long nanoTime();
}
