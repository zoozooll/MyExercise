package com.example.sphere.cardboard2.sensor;

import com.example.sphere.cardboard2.sensor.Clock;

public class SystemClock implements Clock {
    public SystemClock() {
    }

    public long nanoTime() {
        return System.nanoTime();
    }
}
